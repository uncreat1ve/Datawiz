CREATE FUNCTION my_logs_insert_trigger () RETURNS trigger
	LANGUAGE plpgsql
AS $$
BEGIN
    IF ( NEW.client_id=55) THEN
        INSERT INTO core_product_day_sum_55 VALUES (NEW.*);
    ELSIF ( NEW.client_id=64) THEN
        INSERT INTO core_product_day_sum_64 VALUES (NEW.*);
    ELSIF ( NEW.client_id=106 ) THEN
        INSERT INTO core_product_day_sum_106 VALUES (NEW.*);
    ELSIF ( NEW.client_id=75) THEN
        INSERT INTO core_product_day_sum_75 VALUES (NEW.*);
    ELSIF ( NEW.client_id=80) THEN
        INSERT INTO core_product_day_sum_80 VALUES (NEW.*);
    ELSE
        INSERT INTO core_product_day_sum_other VALUES (NEW.*);
    END IF;
    RETURN NULL;
END;
$$
