CREATE TRIGGER insert_core_product_day_sum
BEFORE INSERT ON core_product_day_sum
FOR EACH ROW EXECUTE PROCEDURE my_logs_insert_trigger()